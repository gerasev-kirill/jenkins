#!/usr/bin/sh


source ./ap2
pip2 install -q -r requirements.python.simple.txt 
