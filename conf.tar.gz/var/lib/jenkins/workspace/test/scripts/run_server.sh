#!/usr/bin/sh

source ./ap2
python2 ./scripts/server.py --as-angular-app
